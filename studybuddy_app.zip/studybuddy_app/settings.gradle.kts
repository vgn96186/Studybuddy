rootProject.name = "StudyBuddy"
include(":app")
