package com.example.studybuddy.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.studybuddy.notifications.NotificationHelper

class SessionWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        // Called when session timer ends. Show completion notification.
        NotificationHelper.showCompletionNotification(applicationContext, "Session complete", "Great job — tap to log notes.")
        return Result.success()
    }
}
