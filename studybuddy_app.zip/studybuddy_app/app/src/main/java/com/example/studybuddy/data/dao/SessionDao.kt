package com.example.studybuddy.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.studybuddy.data.entity.SessionEntity

@Dao
interface SessionDao {
    @Insert
    suspend fun insert(session: SessionEntity)

    @Query("SELECT * FROM sessions ORDER BY startTs DESC")
    suspend fun getAll(): List<SessionEntity>
}
