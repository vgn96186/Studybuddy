package com.example.studybuddy.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.studybuddy.workers.SessionWorker
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.compose.ui.platform.LocalContext
import java.util.concurrent.TimeUnit

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    Column(modifier = Modifier.padding(16.dp)) {
        Text("StudyBuddy — skeleton")
        Button(onClick = {
            // schedule a sample 25-min session end worker (for demo)
            val req = OneTimeWorkRequestBuilder<SessionWorker>()
                .setInitialDelay(25, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(ctx).enqueue(req)
        }) {
            Text("Start 25-min session (demo)")
        }
    }
}
