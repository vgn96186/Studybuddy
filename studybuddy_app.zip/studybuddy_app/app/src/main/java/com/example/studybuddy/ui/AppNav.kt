package com.example.studybuddy.ui

import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import com.example.studybuddy.ui.screens.HomeScreen

@Composable
fun AppNav() {
    MaterialTheme {
        Surface {
            HomeScreen()
        }
    }
}
