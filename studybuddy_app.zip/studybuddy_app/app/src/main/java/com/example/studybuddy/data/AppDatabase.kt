package com.example.studybuddy.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.studybuddy.data.dao.SessionDao
import com.example.studybuddy.data.entity.SessionEntity

@Database(entities = [SessionEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun sessionDao(): SessionDao
}
